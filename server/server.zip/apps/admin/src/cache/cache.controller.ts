import { Controller } from '@nestjs/common';

@Controller('cache')
export class CacheController {}
