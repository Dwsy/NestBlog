declare function cloneDecorators(from: any, to: any): void;
declare function clonePropDecorators(from: any, to: any, name: any): void;
