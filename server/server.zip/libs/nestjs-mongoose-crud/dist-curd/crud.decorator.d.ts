import {CrudOptionsWithModel} from './crud.interface';

export declare const Crud: (
    options: CrudOptionsWithModel,
) => (target: any) => void;
