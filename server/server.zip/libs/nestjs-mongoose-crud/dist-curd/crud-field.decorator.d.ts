import {Field} from './crud.interface';

export declare const CrudField: (
    field: Field,
) => (target: any, property: string) => void;
